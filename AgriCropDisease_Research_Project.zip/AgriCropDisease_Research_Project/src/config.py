from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_ROOT = Path(r"D:\dsc_1\ML")
MANIFEST_PATH = DATA_ROOT / "crop_disease_manifest.csv"

MODEL_DIR = PROJECT_ROOT / "models"
REPORT_DIR = PROJECT_ROOT / "outputs" / "reports"
FIGURE_DIR = PROJECT_ROOT / "outputs" / "figures"
KNOWLEDGE_DIR = PROJECT_ROOT / "knowledge_base"

for folder in (MODEL_DIR, REPORT_DIR, FIGURE_DIR, KNOWLEDGE_DIR):
    folder.mkdir(parents=True, exist_ok=True)

IMAGE_SIZE = 224
RANDOM_STATE = 42
