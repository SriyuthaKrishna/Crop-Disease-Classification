import argparse
from pathlib import Path
import numpy as np
import torch
from torch import nn
from torchvision import models, transforms
from PIL import Image
import matplotlib.pyplot as plt
import cv2

from config import MODEL_DIR, FIGURE_DIR

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--image",required=True)
    ap.add_argument("--model",default=str(MODEL_DIR/"mobilenetv3_best.pt"))
    args=ap.parse_args()
    ckpt=torch.load(args.model,map_location="cpu")
    classes=ckpt["classes"]; size=ckpt.get("image_size",224)
    model=models.mobilenet_v3_small(weights=None)
    model.classifier[3]=nn.Linear(model.classifier[3].in_features,len(classes))
    model.load_state_dict(ckpt["state_dict"]); model.eval()
    target=model.features[-1]
    activations={}; gradients={}
    def fwd(m,i,o): activations["v"]=o
    def bwd(m,gi,go): gradients["v"]=go[0]
    h1=target.register_forward_hook(fwd); h2=target.register_full_backward_hook(bwd)
    tf=transforms.Compose([transforms.Resize((size,size)),transforms.ToTensor(),
        transforms.Normalize((.485,.456,.406),(.229,.224,.225))])
    image=Image.open(args.image).convert("RGB")
    x=tf(image).unsqueeze(0)
    logits=model(x); idx=int(logits.argmax(1).item())
    model.zero_grad(); logits[0,idx].backward()
    a=activations["v"].detach().numpy()[0]
    g=gradients["v"].detach().numpy()[0]
    weights=g.mean(axis=(1,2))
    cam=np.maximum((weights[:,None,None]*a).sum(axis=0),0)
    cam=cv2.resize(cam,(size,size)); cam=cam/(cam.max()+1e-8)
    rgb=np.array(image.resize((size,size)))
    heat=cv2.applyColorMap(np.uint8(255*cam),cv2.COLORMAP_JET)
    heat=cv2.cvtColor(heat,cv2.COLOR_BGR2RGB)
    overlay=np.uint8(.55*rgb+.45*heat)
    out=FIGURE_DIR/(Path(args.image).stem+"_gradcam.png")
    plt.figure(figsize=(10,4))
    for i,(im,title) in enumerate([(rgb,"Input"),(heat,"Grad-CAM"),(overlay,f"Prediction: {classes[idx]}")]):
        plt.subplot(1,3,i+1); plt.imshow(im); plt.title(title); plt.axis("off")
    plt.tight_layout(); plt.savefig(out,dpi=180); plt.close()
    h1.remove(); h2.remove()
    print(f"Predicted class: {classes[idx]}\nSaved Grad-CAM: {out}")
if __name__=="__main__": main()
