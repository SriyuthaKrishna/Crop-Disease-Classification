from pathlib import Path
import re
from config import KNOWLEDGE_DIR

def chunks(text, size=700):
    paras=[p.strip() for p in re.split(r"\n\s*\n",text) if p.strip()]
    out=[]
    for p in paras:
        for i in range(0,len(p),size):
            out.append(p[i:i+size])
    return out

def main():
    docs=[]
    for path in KNOWLEDGE_DIR.rglob("*"):
        if path.suffix.lower() in {".txt",".md"}:
            try:
                for chunk in chunks(path.read_text(encoding="utf-8",errors="ignore")):
                    docs.append((path.name,chunk))
            except OSError: pass
    if not docs:
        print(f"Add trusted .txt or .md agriculture sources to: {KNOWLEDGE_DIR}")
        return
    print("Local evidence assistant. It retrieves source passages; it does not replace an agronomist.")
    while True:
        q=input("\nQuestion (or 'exit'): ").strip()
        if q.lower() in {"exit","quit"}: break
        terms={t.lower() for t in re.findall(r"[a-zA-Z]{3,}",q)}
        scored=[]
        for name,txt in docs:
            words=set(t.lower() for t in re.findall(r"[a-zA-Z]{3,}",txt))
            score=len(terms & words)
            if score: scored.append((score,name,txt))
        scored.sort(reverse=True)
        if not scored:
            print("No matching evidence found in the local knowledge base.")
            continue
        print("\nRetrieved evidence (verify before acting):")
        for score,name,txt in scored[:3]:
            print(f"\n[Source: {name} | keyword matches: {score}]\n{txt[:900]}")
if __name__=="__main__": main()
