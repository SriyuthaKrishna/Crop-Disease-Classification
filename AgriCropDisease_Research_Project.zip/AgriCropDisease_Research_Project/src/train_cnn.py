import argparse, copy
from pathlib import Path
import numpy as np
import pandas as pd
from PIL import Image
import torch
from torch import nn
from torch.utils.data import Dataset, DataLoader
from torchvision import models, transforms
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, f1_score
from tqdm import tqdm

from config import DATA_ROOT, MANIFEST_PATH, MODEL_DIR, REPORT_DIR, RANDOM_STATE
from data_utils import load_manifest, normalize_split

class ManifestDataset(Dataset):
    def __init__(self, frame, label_encoder, transform):
        self.frame = frame.reset_index(drop=True)
        self.encoder = label_encoder
        self.transform = transform
    def __len__(self): return len(self.frame)
    def __getitem__(self, idx):
        row = self.frame.iloc[idx]
        with Image.open(row.resolved_path) as im:
            image = im.convert("RGB")
        x = self.transform(image)
        y = int(self.encoder.transform([str(row.label)])[0])
        return x, y

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--epochs", type=int, default=5)
    ap.add_argument("--batch-size", type=int, default=16)
    ap.add_argument("--image-size", type=int, default=224)
    ap.add_argument("--workers", type=int, default=0)
    args = ap.parse_args()

    torch.manual_seed(RANDOM_STATE)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    df = load_manifest(MANIFEST_PATH, DATA_ROOT)
    df["split_norm"] = df["split"].map(normalize_split)
    train = df[df.split_norm == "train"].copy()
    val = df[df.split_norm == "val"].copy()
    test = df[df.split_norm == "test"].copy()
    if train.empty or val.empty:
        raise RuntimeError("Train or validation split is empty. Check manifest split values.")
    # Keep only labels represented in training; unknown validation/test labels are filtered.
    encoder = LabelEncoder().fit(train.label.astype(str))
    train = train[train.label.astype(str).isin(encoder.classes_)]
    val = val[val.label.astype(str).isin(encoder.classes_)]
    test = test[test.label.astype(str).isin(encoder.classes_)]

    mean, std = (0.485,0.456,0.406), (0.229,0.224,0.225)
    train_tf = transforms.Compose([
        transforms.Resize((args.image_size,args.image_size)),
        transforms.RandomHorizontalFlip(), transforms.RandomRotation(12),
        transforms.ToTensor(), transforms.Normalize(mean,std)])
    eval_tf = transforms.Compose([
        transforms.Resize((args.image_size,args.image_size)),
        transforms.ToTensor(), transforms.Normalize(mean,std)])
    train_loader = DataLoader(ManifestDataset(train,encoder,train_tf), batch_size=args.batch_size,
                              shuffle=True,num_workers=args.workers)
    val_loader = DataLoader(ManifestDataset(val,encoder,eval_tf), batch_size=args.batch_size,
                            shuffle=False,num_workers=args.workers)
    test_loader = DataLoader(ManifestDataset(test,encoder,eval_tf), batch_size=args.batch_size,
                             shuffle=False,num_workers=args.workers)

    weights = models.MobileNet_V3_Small_Weights.DEFAULT
    model = models.mobilenet_v3_small(weights=weights)
    model.classifier[3] = nn.Linear(model.classifier[3].in_features, len(encoder.classes_))
    model.to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4)
    best_f1, best_state = -1, copy.deepcopy(model.state_dict())

    for epoch in range(args.epochs):
        model.train(); losses=[]
        for x,y in tqdm(train_loader, desc=f"Epoch {epoch+1}/{args.epochs}"):
            x,y=x.to(device),y.to(device)
            optimizer.zero_grad()
            logits=model(x); loss=criterion(logits,y)
            loss.backward(); optimizer.step()
            losses.append(loss.item())
        model.eval(); truth=[]; pred=[]
        with torch.no_grad():
            for x,y in val_loader:
                out=model(x.to(device)).argmax(1).cpu().numpy()
                truth.extend(y.numpy()); pred.extend(out)
        score=f1_score(truth,pred,average="macro",zero_division=0)
        print(f"Epoch {epoch+1}: loss={np.mean(losses):.4f}, val_macro_f1={score:.4f}")
        if score > best_f1:
            best_f1=score; best_state=copy.deepcopy(model.state_dict())
            torch.save({"state_dict":best_state,"classes":encoder.classes_.tolist(),
                        "image_size":args.image_size}, MODEL_DIR/"mobilenetv3_best.pt")

    model.load_state_dict(best_state); model.eval()
    truth=[]; pred=[]
    with torch.no_grad():
        for x,y in test_loader:
            pred.extend(model(x.to(device)).argmax(1).cpu().numpy())
            truth.extend(y.numpy())
    if truth:
        report = {"accuracy":accuracy_score(truth,pred),
                  "macro_f1":f1_score(truth,pred,average="macro",zero_division=0),
                  "test_samples":len(truth),"classes":encoder.classes_.tolist()}
        pd.DataFrame([report]).to_csv(REPORT_DIR/"mobilenet_test_metrics.csv",index=False)
        print(report)
    print(f"Best checkpoint saved to {MODEL_DIR/'mobilenetv3_best.pt'}")

if __name__ == "__main__":
    main()
