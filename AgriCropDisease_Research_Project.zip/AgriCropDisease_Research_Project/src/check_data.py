from pathlib import Path
from config import DATA_ROOT, MANIFEST_PATH, REPORT_DIR
from data_utils import load_manifest, normalize_split

df = load_manifest(MANIFEST_PATH, DATA_ROOT)
df["split_norm"] = df["split"].map(normalize_split)
exists = df["resolved_path"].map(lambda p: Path(p).is_file())
lines = [
    f"Manifest rows: {len(df)}",
    f"Existing image files: {int(exists.sum())}",
    f"Missing image files: {int((~exists).sum())}",
    "",
    "Rows by dataset and split:",
    df.groupby(["dataset", "split_norm"]).size().to_string(),
    "",
    "Classes by dataset:",
    df.groupby("dataset")["label"].nunique().to_string(),
]
missing = df.loc[~exists, ["image_path", "resolved_path"]].head(50)
if len(missing):
    lines += ["", "First missing paths:", missing.to_string(index=False)]
out = REPORT_DIR / "data_validation.txt"
out.write_text("\n".join(lines), encoding="utf-8")
print("\n".join(lines))
print(f"\nSaved: {out}")
