import argparse, json
from collections import defaultdict
from pathlib import Path
import cv2
import numpy as np
import pandas as pd
from tqdm import tqdm
from skimage.feature import hog, local_binary_pattern
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, f1_score, classification_report
from sklearn.model_selection import train_test_split
import joblib

from config import DATA_ROOT, MANIFEST_PATH, MODEL_DIR, REPORT_DIR, RANDOM_STATE
from data_utils import load_manifest, normalize_split

def features(path, use_lbp=False):
    img = cv2.imread(str(path))
    if img is None:
        return None
    img = cv2.resize(img, (128, 128))
    rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    h = hog(gray, orientations=9, pixels_per_cell=(8,8),
            cells_per_block=(2,2), block_norm="L2-Hys")
    hist = []
    for ch in cv2.split(rgb):
        hist.extend(cv2.calcHist([ch], [0], None, [32], [0,256]).flatten())
    result = [h, np.asarray(hist, dtype=np.float32)]
    if use_lbp:
        lbp = local_binary_pattern(gray, P=8, R=1, method="uniform")
        lbp_hist, _ = np.histogram(lbp.ravel(), bins=np.arange(0, 11), density=True)
        result.append(lbp_hist.astype(np.float32))
    return np.concatenate(result)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--max-per-class", type=int, default=500)
    ap.add_argument("--use-lbp", action="store_true")
    args = ap.parse_args()

    df = load_manifest(MANIFEST_PATH, DATA_ROOT)
    df["split_norm"] = df["split"].map(normalize_split)
    df = df[df["split_norm"].isin(["train", "val", "test"])]
    # Use only train and validation for fitting; reserve the manifest test split.
    train_df = df[df["split_norm"].isin(["train", "val"])].copy()
    test_df = df[df["split_norm"] == "test"].copy()
    train_df = train_df.groupby("label", group_keys=False).head(args.max_per_class)

    X_train, y_train, X_test, y_test = [], [], [], []
    for frame, X, y in [(train_df, X_train, y_train), (test_df, X_test, y_test)]:
        for row in tqdm(frame.itertuples(), total=len(frame)):
            f = features(row.resolved_path, args.use_lbp)
            if f is not None:
                X.append(f); y.append(str(row.label))
    if not X_train or not X_test:
        raise RuntimeError("No readable training/test images. Run python src/check_data.py and inspect the report.")

    enc = LabelEncoder()
    ytr = enc.fit_transform(y_train)
    yte = enc.transform([v if v in enc.classes_ else enc.classes_[0] for v in y_test])
    # Ignore test labels unseen during fitting; report how many are excluded.
    known = np.array([v in set(enc.classes_) for v in y_test])
    X_test = np.asarray(X_test)[known]
    yte = yte[known]
    y_test_known = np.asarray(y_test)[known]
    X_train = np.asarray(X_train)

    models = {
        "SVM": make_pipeline(StandardScaler(), SVC(kernel="rbf", class_weight="balanced")),
        "RandomForest": RandomForestClassifier(n_estimators=250, class_weight="balanced_subsample",
                                               random_state=RANDOM_STATE, n_jobs=-1),
        "KNN": make_pipeline(StandardScaler(), KNeighborsClassifier(n_neighbors=5, n_jobs=-1)),
    }
    results = []
    for name, model in models.items():
        model.fit(X_train, ytr)
        pred = model.predict(X_test)
        results.append({"model": name, "accuracy": accuracy_score(yte, pred),
                        "macro_f1": f1_score(yte, pred, average="macro", zero_division=0)})
        joblib.dump({"model": model, "label_encoder": enc},
                    MODEL_DIR / f"traditional_{name.lower()}.joblib")
        (REPORT_DIR / f"traditional_{name.lower()}_report.txt").write_text(
            classification_report(yte, pred, target_names=enc.classes_, zero_division=0),
            encoding="utf-8")
    pd.DataFrame(results).to_csv(REPORT_DIR / "traditional_metrics.csv", index=False)
    print(pd.DataFrame(results).to_string(index=False))
    print(f"Saved results in {REPORT_DIR}")

if __name__ == "__main__":
    main()
