import argparse
import pandas as pd
import torch
from torch import nn
from torch.utils.data import DataLoader
from torchvision import models, transforms
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, f1_score
from pathlib import Path
from PIL import Image
import matplotlib.pyplot as plt
import numpy as np

from config import DATA_ROOT, MANIFEST_PATH, MODEL_DIR, REPORT_DIR, FIGURE_DIR
from data_utils import load_manifest, normalize_split

class EvalDataset(torch.utils.data.Dataset):
    def __init__(self, df, classes, size):
        self.df=df.reset_index(drop=True); self.classes=classes
        self.tf=transforms.Compose([transforms.Resize((size,size)),transforms.ToTensor(),
            transforms.Normalize((.485,.456,.406),(.229,.224,.225))])
        self.map={c:i for i,c in enumerate(classes)}
    def __len__(self): return len(self.df)
    def __getitem__(self,i):
        r=self.df.iloc[i]
        with Image.open(r.resolved_path) as im: x=self.tf(im.convert("RGB"))
        return x,self.map[str(r.label)],str(r.dataset)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--model",default=str(MODEL_DIR/"mobilenetv3_best.pt"))
    ap.add_argument("--batch-size",type=int,default=16)
    args=ap.parse_args()
    ckpt=torch.load(args.model,map_location="cpu")
    classes=ckpt["classes"]; size=ckpt.get("image_size",224)
    df=load_manifest(MANIFEST_PATH,DATA_ROOT); df["split_norm"]=df.split.map(normalize_split)
    df=df[(df.split_norm=="test") & df.label.astype(str).isin(classes)]
    ds=EvalDataset(df,classes,size)
    loader=DataLoader(ds,batch_size=args.batch_size,shuffle=False,num_workers=0)
    model=models.mobilenet_v3_small(weights=None)
    model.classifier[3]=nn.Linear(model.classifier[3].in_features,len(classes))
    model.load_state_dict(ckpt["state_dict"]); model.eval()
    device=torch.device("cuda" if torch.cuda.is_available() else "cpu"); model.to(device)
    y,p,groups=[],[],[]
    with torch.no_grad():
        for x,t,g in loader:
            p.extend(model(x.to(device)).argmax(1).cpu().numpy())
            y.extend(t.numpy()); groups.extend(g)
    if not y: raise RuntimeError("No test images found for checkpoint classes.")
    report=classification_report(y,p,target_names=classes,zero_division=0)
    (REPORT_DIR/"mobilenet_classification_report.txt").write_text(report,encoding="utf-8")
    pd.DataFrame([{"accuracy":accuracy_score(y,p),"macro_f1":f1_score(y,p,average="macro",zero_division=0)}]).to_csv(REPORT_DIR/"mobilenet_overall_metrics.csv",index=False)
    rows=[]
    for dataset in sorted(set(groups)):
        ix=[i for i,g in enumerate(groups) if g==dataset]
        rows.append({"dataset":dataset,"samples":len(ix),
                     "accuracy":accuracy_score(np.array(y)[ix],np.array(p)[ix]),
                     "macro_f1":f1_score(np.array(y)[ix],np.array(p)[ix],average="macro",zero_division=0)})
    pd.DataFrame(rows).to_csv(REPORT_DIR/"mobilenet_dataset_wise_metrics.csv",index=False)
    cm=confusion_matrix(y,p)
    plt.figure(figsize=(12,10)); plt.imshow(cm); plt.title("MobileNetV3-Small Confusion Matrix")
    plt.xlabel("Predicted"); plt.ylabel("True"); plt.colorbar(); plt.tight_layout()
    plt.savefig(FIGURE_DIR/"mobilenet_confusion_matrix.png",dpi=180); plt.close()
    print(report); print(pd.DataFrame(rows).to_string(index=False))
if __name__=="__main__": main()
