from pathlib import Path
import pandas as pd
from PIL import Image

REQUIRED_COLUMNS = {"image_path", "label", "dataset", "split"}

def load_manifest(path, data_root):
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(
            f"Manifest not found: {path}\nUpdate MANIFEST_PATH in src/config.py."
        )
    df = pd.read_csv(path)
    missing = REQUIRED_COLUMNS - set(df.columns)
    if missing:
        raise ValueError(f"Manifest missing required columns: {sorted(missing)}")
    df = df.dropna(subset=["image_path", "label", "dataset", "split"]).copy()
    root = Path(data_root)

    def resolve(p):
        p = Path(str(p).strip().strip('"'))
        return p if p.is_absolute() else root / p

    df["resolved_path"] = df["image_path"].map(resolve)
    df["label"] = df["label"].astype(str)
    df["dataset"] = df["dataset"].astype(str)
    df["split"] = df["split"].astype(str).str.lower()
    return df

def safe_image(path):
    try:
        with Image.open(path) as im:
            return im.convert("RGB")
    except Exception:
        return None

def normalize_split(value):
    s = str(value).lower()
    if "train" in s:
        return "train"
    if "val" in s or "valid" in s:
        return "val"
    if "test" in s:
        return "test"
    return s
