
import os
import hashlib
import pandas as pd

root = r"D:\dsc_1\ML\MyDrive\CropDiseaseProject"

input_file = os.path.join(
    root, "crop_disease_manifest_final.csv"
)

output_file = os.path.join(
    root, "crop_disease_manifest_clean.csv"
)

report_file = os.path.join(
    root, "duplicate_resolution_report.csv"
)

df = pd.read_csv(input_file)

def image_hash(path):
    h = hashlib.sha256()

    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)

    return h.hexdigest()

print("Calculating image hashes...")

df["sha256"] = df["image_path"].apply(image_hash)

# Priority: preserve test, then validation, then train
priority = {
    "test": 0,
    "validation": 1,
    "train": 2
}

df["_priority"] = df["split"].map(priority).fillna(3)

# Check that duplicates within a dataset have the same label
for (dataset, digest), group in df.groupby(
    ["dataset", "sha256"]
):
    if group["label"].nunique() > 1:
        raise ValueError(
            f"Label conflict found: {dataset}, {digest}"
        )

# Select one representative for each dataset/hash group
df = df.sort_values(
    ["_priority", "image_path"]
)

duplicates = df[
    df.duplicated(["dataset", "sha256"], keep=False)
].copy()

duplicates["kept"] = ~duplicates.duplicated(
    ["dataset", "sha256"], keep="first"
)

duplicates.to_csv(report_file, index=False)

clean = df.drop_duplicates(
    ["dataset", "sha256"],
    keep="first"
).copy()

clean = clean.drop(
    columns=["sha256", "_priority"]
)

clean.to_csv(output_file, index=False)

print("\n========== CLEANING SUMMARY ==========")
print("Original records:", len(pd.read_csv(input_file)))
print("Clean records:", len(clean))
print("Removed duplicate records:", len(df) - len(clean))

print("\nCleaned dataset counts:")
print(clean.groupby(["dataset", "split"]).size())

print("\nSaved cleaned manifest:")
print(output_file)

print("\nSaved duplicate resolution report:")
print(report_file)

print("\nCLEANING COMPLETED")
