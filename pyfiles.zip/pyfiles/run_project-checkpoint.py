
import os
import hashlib
import pandas as pd

# ==========================================
# CROP DISEASE PROJECT - MASTER PIPELINE
# ==========================================

ROOT = r"D:\dsc_1\ML\MyDrive\CropDiseaseProject"

MANIFEST = os.path.join(
    ROOT, "crop_disease_manifest_final.csv"
)

CASSAVA_CSV = os.path.join(
    ROOT, "datasets", "Cassava Leaf Disease", "train.csv"
)

CLEAN_MANIFEST = os.path.join(
    ROOT, "crop_disease_manifest_clean.csv"
)

DUPLICATE_REPORT = os.path.join(
    ROOT, "duplicate_resolution_report.csv"
)

print("=" * 55)
print("       CROP DISEASE DETECTION PROJECT")
print("              MASTER PIPELINE")
print("=" * 55)

# 1. LOAD DATASET
print("\n[1/5] Loading dataset...")

df = pd.read_csv(MANIFEST)

print("Total records:", len(df))

# 2. VERIFY IMAGE PATHS
print("\n[2/5] Checking image paths...")

missing = df[~df["image_path"].apply(os.path.isfile)]

print("Missing images:", len(missing))

if len(missing) > 0:
    print(missing[["image_path"]].head(10))
    raise SystemExit("STOP: Fix missing image paths first.")

# 3. VERIFY CASSAVA LABELS
print("\n[3/5] Verifying Cassava labels...")

cassava = df[df["dataset"] == "Cassava"].copy()
official = pd.read_csv(CASSAVA_CSV)

cassava["image_id"] = cassava["image_path"].apply(
    lambda p: os.path.basename(str(p))
)

official["image_id"] = official["image_id"].astype(str)

merged = cassava.merge(
    official[["image_id", "label"]],
    on="image_id",
    how="left",
    suffixes=("_manifest", "_official"),
    validate="one_to_one"
)

merged["label_match"] = (
    pd.to_numeric(merged["label_manifest"], errors="coerce")
    == pd.to_numeric(merged["label_official"], errors="coerce")
)

if not merged["label_match"].all():
    raise SystemExit("STOP: Cassava label mismatch detected.")

print("Cassava labels verified:", len(merged))

# 4. EXACT DUPLICATE DETECTION
print("\n[4/5] Checking duplicate images...")
print("Please wait while image hashes are calculated.")

def get_hash(path):
    h = hashlib.sha256()

    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)

    return h.hexdigest()

df["sha256"] = df["image_path"].apply(get_hash)

# Keep evaluation copies before training copies
priority = {
    "test": 0,
    "validation": 1,
    "train": 2
}

df["_priority"] = df["split"].map(priority).fillna(3)

# Detect conflicting labels
for (dataset, digest), group in df.groupby(
    ["dataset", "sha256"]
):
    if group["label"].nunique() > 1:
        raise SystemExit(
            f"STOP: Duplicate images have conflicting labels: {dataset}"
        )

duplicate_rows = df[
    df.duplicated(["dataset", "sha256"], keep=False)
].copy()

# 5. CLEAN DUPLICATES
print("\n[5/5] Preparing cleaned manifest...")

df = df.sort_values(
    ["_priority", "image_path"]
)

# Select one copy per dataset and image hash
clean = df.drop_duplicates(
    ["dataset", "sha256"],
    keep="first"
).copy()

# Create a detailed duplicate resolution report
report_rows = []

for (dataset, digest), group in duplicate_rows.groupby(
    ["dataset", "sha256"]
):
    selected = clean[
        (clean["dataset"] == dataset)
        & (clean["sha256"] == digest)
    ].iloc[0]

    report_rows.append({
        "dataset": dataset,
        "sha256": digest,
        "copies": len(group),
        "original_splits": ", ".join(
            sorted(group["split"].unique())
        ),
        "cross_split": group["split"].nunique() > 1,
        "kept_path": selected["image_path"],
        "removed_paths": " | ".join(
            p for p in group["image_path"]
            if p != selected["image_path"]
        )
    })

report = pd.DataFrame(report_rows)

report.to_csv(DUPLICATE_REPORT, index=False)

clean = clean.drop(columns=["sha256", "_priority"])

clean.to_csv(CLEAN_MANIFEST, index=False)

# FINAL SUMMARY
print("\n" + "=" * 55)
print("             FINAL PIPELINE REPORT")
print("=" * 55)

print("Original images:", len(df))
print("Cleaned records:", len(clean))
print("Removed duplicates:", len(df) - len(clean))
print(
    "Duplicate groups:",
    len(report)
)
print(
    "Groups crossing splits:",
    int(report["cross_split"].sum()) if len(report) else 0
)

print("\nCLEAN DATASET DISTRIBUTION")
print(clean.groupby(["dataset", "split"]).size())

print("\nOUTPUT FILES")
print("Clean manifest:", CLEAN_MANIFEST)
print("Duplicate report:", DUPLICATE_REPORT)

print("\nMASTER PIPELINE COMPLETED SUCCESSFULLY!")
