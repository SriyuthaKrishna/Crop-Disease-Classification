
import os
import pandas as pd

root = r"D:\dsc_1\ML\MyDrive\CropDiseaseProject"
cassava = os.path.join(root, "datasets", "Cassava Leaf Disease")

manifest = pd.read_csv(
    os.path.join(root, "crop_disease_manifest_final.csv")
)

official = pd.read_csv(os.path.join(cassava, "train.csv"))

data = manifest[manifest["dataset"] == "Cassava"].copy()

data["image_id"] = data["image_path"].apply(
    lambda p: os.path.basename(str(p))
)

data["label"] = pd.to_numeric(data["label"])
official["label"] = pd.to_numeric(official["label"])

merged = data.merge(
    official[["image_id", "label"]],
    on="image_id",
    how="left",
    suffixes=("_manifest", "_official"),
    validate="one_to_one"
)

merged["label_match"] = (
    merged["label_manifest"] == merged["label_official"]
)

print("\nLABEL VERIFICATION")
print("Total records:", len(merged))
print("Correct labels:", merged["label_match"].sum())
print("Incorrect labels:", (~merged["label_match"]).sum())

print("\nLABEL AGREEMENT BY SPLIT")
print(merged.groupby("split")["label_match"].agg(["sum", "count"]))

print("\nFINAL RESULT:")
if merged["label_match"].all():
    print("PASS: All Cassava labels match official train.csv")
else:
    print("WARNING: Some labels do not match.")
    print(merged.loc[~merged["label_match"]].head(20))
