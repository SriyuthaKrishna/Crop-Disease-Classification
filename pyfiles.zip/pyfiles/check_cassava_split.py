
import os
import pandas as pd

root = r"D:\dsc_1\ML\MyDrive\CropDiseaseProject"
dataset = os.path.join(root, "datasets", "Cassava Leaf Disease")

manifest_path = os.path.join(root, "crop_disease_manifest_final.csv")
train_csv = os.path.join(dataset, "train.csv")

df = pd.read_csv(manifest_path)
cassava = df[df["dataset"].str.lower() == "cassava"].copy()

labels = pd.read_csv(train_csv)

# Normalize image IDs so filenames and CSV IDs can be compared
def normalize_id(value):
    return os.path.splitext(os.path.basename(str(value)))[0].lower()

train_ids = set(labels["image_id"].map(normalize_id))
cassava["normalized_id"] = cassava["image_path"].map(normalize_id)

print("\n--- CASSAVA SPLIT COUNTS ---")
print(cassava.groupby(["split", cassava["image_path"].str.contains(
    "test_images", case=False).map({True: "test_images", False: "other_images"}
)]).size())

print("\n--- IMAGE FOLDER DISTRIBUTION ---")
cassava["folder"] = cassava["image_path"].apply(
    lambda p: "test_images" if "test_images" in p.lower()
    else "train_images" if "train_images" in p.lower()
    else "other"
)
print(pd.crosstab(cassava["split"], cassava["folder"]))

print("\n--- MATCH AGAINST OFFICIAL train.csv ---")
cassava["in_train_csv"] = cassava["normalized_id"].isin(train_ids)
print(pd.crosstab(cassava["split"], cassava["in_train_csv"]))

print("\n--- SAMPLE RECORDS ---")
print(cassava[["image_id", "label", "split", "folder",
               "in_train_csv"]].head(15).to_string(index=False))

print("\n--- SUMMARY ---")
print("Manifest Cassava records:", len(cassava))
print("IDs found in official train.csv:", cassava["in_train_csv"].sum())
print("IDs not found in official train.csv:",
      (~cassava["in_train_csv"]).sum())

print("\nAUDIT COMPLETED")
