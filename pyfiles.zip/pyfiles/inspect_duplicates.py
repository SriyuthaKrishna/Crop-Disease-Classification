
import os
import pandas as pd

root = r"D:\dsc_1\ML\MyDrive\CropDiseaseProject"
report_path = os.path.join(root, "duplicate_image_report.csv")

df = pd.read_csv(report_path)

print("\n========== DUPLICATE IMAGE DETAILS ==========")

for i, row in df.iterrows():
    print(f"\nDuplicate Group: {i + 1}")
    print("Dataset:", row["dataset"])
    print("Copies:", row["number_of_copies"])
    print("Splits:", row["splits"])
    print("Number of splits:", row["number_of_splits"])
    print("Image paths:")

    for path in str(row["paths"]).split(" | "):
        print("  ", path)

print("\n========== SUMMARY ==========")
print("Total duplicate groups:", len(df))
print(
    "Groups crossing splits:",
    (df["number_of_splits"] > 1).sum()
)
