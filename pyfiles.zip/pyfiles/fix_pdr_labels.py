
import pandas as pd
import os

project = r"D:\dsc_1\ML\MyDrive\CropDiseaseProject"

input_file = os.path.join(
    project, "crop_disease_manifest_fixed.csv"
)

output_file = os.path.join(
    project, "crop_disease_manifest_final.csv"
)

# Read corrected-path manifest
df = pd.read_csv(input_file)

# Correct PDR labels using the actual class folder
mask = df["dataset"] == "PDR"

df.loc[mask, "label"] = df.loc[mask, "image_path"].apply(
    lambda path: os.path.basename(os.path.dirname(path))
)

# Validate PDR classes
pdr = df[mask]

expected_classes = {"Healthy", "Powdery", "Rust"}
actual_classes = set(pdr["label"].unique())

print("\nPDR CLASSES:", sorted(actual_classes))

if actual_classes != expected_classes:
    raise ValueError(
        f"Unexpected PDR classes: {actual_classes}"
    )

# Verify all image paths
df["exists"] = df["image_path"].apply(os.path.isfile)

print("\nIMAGE VALIDATION:")
print("Total:", len(df))
print("Existing:", df["exists"].sum())
print("Missing:", (~df["exists"]).sum())

if not df["exists"].all():
    raise ValueError("Missing images found. Stopping.")

# Display corrected PDR distribution
print("\nPDR CLASS DISTRIBUTION:")
print(pd.crosstab(pdr["label"], pdr["split"]))

# Remove temporary column
df.drop(columns=["exists"], inplace=True)

# Save separately; preserve previous manifests
df.to_csv(output_file, index=False)

print("\nSUCCESS! Final manifest saved:")
print(output_file)

print("\nALL DATASET CLASS COUNTS:")
print(df.groupby("dataset")["label"].nunique())
