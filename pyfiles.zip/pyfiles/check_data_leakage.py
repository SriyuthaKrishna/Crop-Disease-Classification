
import pandas as pd
import hashlib
import os
from collections import defaultdict

root = r"D:\dsc_1\ML\MyDrive\CropDiseaseProject"

manifest = os.path.join(
    root, "crop_disease_manifest_final.csv"
)

df = pd.read_csv(manifest)

# Calculate SHA-256 for each image
def image_hash(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

print("Checking image contents...")
print("This may take a few minutes for 43,417 images.")

df["sha256"] = df["image_path"].apply(image_hash)

# Check duplicate images within each dataset
duplicate_groups = []

for dataset, group in df.groupby("dataset"):
    for digest, images in group.groupby("sha256"):
        if len(images) > 1:
            duplicate_groups.append({
                "dataset": dataset,
                "sha256": digest,
                "paths": " | ".join(images["image_path"]),
                "splits": ", ".join(sorted(images["split"].unique())),
                "number_of_copies": len(images),
                "number_of_splits": images["split"].nunique()
            })

report = pd.DataFrame(duplicate_groups)

if len(report) == 0:
    print("\nNo identical images found within datasets.")
else:
    print("\nDuplicate image groups:", len(report))
    print(
        "Groups crossing train/validation/test:",
        (report["number_of_splits"] > 1).sum()
    )

    output = os.path.join(root, "duplicate_image_report.csv")
    report.to_csv(output, index=False)
    print("Report saved:", output)

print("\nDATASET-WISE IMAGE COUNTS")
print(df.groupby(["dataset", "split"]).size())

print("\nHASH CHECK COMPLETED")
