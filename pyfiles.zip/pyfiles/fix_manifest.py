
import pandas as pd
import os

# Project locations
project = r"D:\dsc_1\ML"
manifest = os.path.join(
    project, "MyDrive", "CropDiseaseProject",
    "crop_disease_manifest.csv"
)

dataset_root = os.path.join(
    project, "MyDrive", "CropDiseaseProject", "datasets"
)

# Dataset folder names
folders = {
    "PlantVillage": "PlantVillage",
    "PDR": "Plant Disease Recognition",
    "Cassava": "Cassava Leaf Disease"
}

# Load original manifest
df = pd.read_csv(manifest)

corrected_paths = []

for _, row in df.iterrows():
    dataset = row["dataset"]
    old_path = row["image_path"]

    old_dataset_root = os.path.join(project, folders[dataset])
    new_dataset_root = os.path.join(dataset_root, folders[dataset])

    # Preserve the path relative to its original dataset folder
    relative_path = os.path.relpath(old_path, old_dataset_root)
    new_path = os.path.join(new_dataset_root, relative_path)

    corrected_paths.append(new_path)

# Update paths in memory only
df["image_path"] = corrected_paths

# Verify every image
df["path_exists"] = df["image_path"].apply(os.path.isfile)

missing = df[~df["path_exists"]]

print("\nDATASET VALIDATION")
print(df.groupby("dataset")["path_exists"].agg(["count", "sum"]))

print("\nTotal records:", len(df))
print("Existing images:", df["path_exists"].sum())
print("Missing images:", len(missing))

if len(missing) > 0:
    missing.to_csv(
        os.path.join(project, "missing_images_report.csv"),
        index=False
    )
    raise SystemExit("STOP: Missing images found. Check the report.")

# Remove temporary validation column
df.drop(columns=["path_exists"], inplace=True)

# Save new manifest, preserving original
output = os.path.join(
    project, "MyDrive", "CropDiseaseProject",
    "crop_disease_manifest_fixed.csv"
)

df.to_csv(output, index=False)

print("\nSUCCESS!")
print("Corrected manifest saved at:")
print(output)

print("\nDataset split counts:")
print(pd.crosstab(df["dataset"], df["split"]))

print("\nLabel counts:")
print(df.groupby("dataset")["label"].nunique())
